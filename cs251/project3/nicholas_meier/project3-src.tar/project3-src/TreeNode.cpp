#include <iostream>
#include "TreeNode.h"

#include <string>


TreeNode::TreeNode(unsigned char, unsigned int)
{

}

unsigned TreeNode::getFrequency()
{
	return frequency;
}
unsigned TreeNode::getVal()
{
	return val;
}