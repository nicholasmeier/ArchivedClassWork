#include <iostream>
#include "HuffTree.h"
