#include <iostream>
#include <climits>

#include "MinHeap.h"



//implement the methods in MinHeap.h

MinHeap::MinHeap()
{

}

void MinHeap::insert(TreeNode * val)
{

}

int MinHeap::getSize()
{
	return -1;
}

TreeNode * MinHeap::removeMin()
{

	return NULL;

}


